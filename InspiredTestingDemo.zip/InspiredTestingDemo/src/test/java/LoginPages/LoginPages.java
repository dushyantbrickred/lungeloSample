package LoginPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPages {
    WebDriver driver;

    @FindBy(id = "user-name")
    WebElement txt_username;
    @FindBy(id = "password")
    WebElement txt_password;
    @FindBy(id = "login-button")
    WebElement btn_login_btn;


    public LoginPages(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver, this);
    }

    public void SetUsername(String username){

        txt_username.sendKeys(username);
    }
    public void SetPassword(String password){

        txt_password.sendKeys(password);
    }

    public void SelectLoginBTN(){

        btn_login_btn.click();
    }


}
