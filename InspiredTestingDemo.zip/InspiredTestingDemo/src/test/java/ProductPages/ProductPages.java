package ProductPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPages {
    WebDriver driver;

    @FindBy(name = "add-to-cart-sauce-labs-backpack")
    WebElement add_product1;

    @FindBy(id = "add-to-cart-sauce-labs-bike-light")
    WebElement add_product2;

    @FindBy(className = "shopping_cart_link")
    WebElement goto_cart;

    @FindBy(id = "remove-sauce-labs-backpack")
    WebElement btn_remove;

    @FindBy(id = "checkout")
    WebElement btn_checkout;

    @FindBy(id = "first-name")
    WebElement txt_firstname;

    @FindBy(id = "last-name")
    WebElement txt_lastname;

    @FindBy(id = "postal-code")
    WebElement txtZipCode;

    @FindBy(id = "continue")
    WebElement btn_continue;

    @FindBy(id = "finish")
    WebElement btn_finish;

    public ProductPages(WebDriver _driver){
        this.driver = _driver;
        PageFactory.initElements(driver, this);
    }

    public void setAdd_product1(){

        add_product1.click();
    }
    public void setAdd_product2(){

        add_product2.click();
    }

    public void ClickCart(){

        goto_cart.click();
    }
    public void setBtn_remove(){

        btn_remove.click();
    }
    public void setBtn_checkout(){

        btn_checkout.click();
    }

    public void setTxt_firstname(String firstname){

        txt_firstname.sendKeys(firstname);
    }
    public void setTxt_lastname(String lastname){

        txt_lastname.sendKeys(lastname);
    }
    public void setTxtZipCode(String zipCode){

        txtZipCode.sendKeys(zipCode);
    }

    public void setBtn_continue(){

        btn_continue.click();
    }

    public void setBtn_finish(){

        btn_finish.click();
    }
}
