package TestCases;

import LoginPages.LoginPages;
import ProductPages.ProductPages;
import TestBase.BaseClass;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;


public class TestCases extends BaseClass {
    LoginPages pages;
    ProductPages products;

    @Test
    public void LaunchBrowser(){
        driver.get(url);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS) ;
    }
    @Test(priority = 1)
    public void Login(){
        pages = new LoginPages(driver);
        pages.SetUsername(username);
        pages.SetPassword(password);
        pages.SelectLoginBTN();
    }
    @Test(priority = 2)
    public void AddProduct(){
        products = new ProductPages(driver);

        products.setAdd_product1();
        products.setAdd_product2();
        products.ClickCart();
        products.setBtn_remove();
        products.setBtn_checkout();
        products.setTxt_firstname(firstname);
        products.setTxt_lastname(lastname);
        products.setTxtZipCode(ZipCode);
        products.setBtn_continue();
        products.setBtn_finish();
    }

}
