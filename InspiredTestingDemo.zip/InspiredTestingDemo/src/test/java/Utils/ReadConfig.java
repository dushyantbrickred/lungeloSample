package Utils;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfig {

    Properties properties;

    public ReadConfig(){
        File source = new File("./Configuration/ConfigFile.properties");
        try{
            FileInputStream file = new FileInputStream(source);
            properties = new Properties();
            properties.load(file);

        }catch (Exception ex){
            System.out.println("Exception message is: " + ex.getMessage());
        }
    }
    public String getUrlBase(){
        String url = properties.getProperty("url");
        return url;
    }
    public String getUsername(){
        String username = properties.getProperty("username");
        return username;
    }
    public String getPassword(){
        String password = properties.getProperty("password");
        return password;
    }

    //
    public String getFirstname(){
        String firstname = properties.getProperty("firstname");
        return firstname;
    }
    public String getLastname(){
        String lastname = properties.getProperty("lastname");
        return lastname;
    }
    public String getZipCode(){
        String ZipCode = properties.getProperty("ZipCode");
        return ZipCode;
    }
    public void product1()
    {

    }

    }