package TestBase;


import ProductPages.ProductPages;
import Utils.ReadConfig;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


public class BaseClass {
    ReadConfig readConfig = new ReadConfig();

    public static WebDriver driver;

    public String url = readConfig.getUrlBase();
    public String username = readConfig.getUsername();
    public String password = readConfig.getPassword();


    //products

    public String firstname = readConfig.getFirstname();
    public String lastname = readConfig.getLastname();
    public String ZipCode = readConfig.getZipCode();

    @BeforeTest
    public void setUp(){
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
    }

    /*@AfterSuite
    public void tearDown(ITestResult result){

        driver.close();
    }*/

}

